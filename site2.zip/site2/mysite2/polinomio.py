import numpy as np
import matplotlib.pyplot as plt
def coeficiente(a = str()):
    lista = list()
    for i, v in enumerate(a):
        n = ''
        if v == '{':
            k = i
            while True:
                if a[k+1] == '}':
                    break
                k+=1
                n = n+a[k]
        lista.append(n)
        if '' in lista:
            lista.remove('')
    return lista

def root(lista_de_coeficientes2 = list(), lista_de_coeficientes3 = list()):
    d = {}
    m = max(lista_de_coeficientes2)
    for i in range(0,m+1):
        d[f'{i}'] = 0
    k = 0
    while True:
        if k in lista_de_coeficientes2:
           p = lista_de_coeficientes2.index(k)
           d[f'{k}'] = lista_de_coeficientes3[p]
        if k>m:
            break
        k+=1    
    return d

def poly(eq = str()):
    lista_de_coeficientes = []
    lista_de_coeficientes2 = []
    lista_de_coeficientes3 = []
    polinomio = []
    lista_de_caracteres = ['-','+']
    if not eq[0].isdigit() and not eq[0] in lista_de_caracteres:
        lista_de_coeficientes.append('1') 
    
    for i, v in enumerate(eq):
        if v in lista_de_caracteres and eq[i+1].isdigit() or v.isdigit() and i == 0:
                k = i
                inicio = ''
                while True:
                    inicio = inicio + eq[k]
                    k+=1
                    if not eq[k].isdigit():
                        lista_de_coeficientes.append(inicio)
                        break
        elif not v.isdigit() and eq[i-1] in lista_de_caracteres:
            lista_de_coeficientes.append(eq[i-1]+'1')
    lista = coeficiente(eq)
    for _, v in enumerate(lista):
        lista_de_coeficientes2.append(int(v))
    for i in lista_de_coeficientes:
            lista_de_coeficientes3.append(int(i))
    d = root(lista_de_coeficientes2, lista_de_coeficientes3)
    for v in d.values():
        polinomio.append(v)
    polinomio.reverse()
    poly = np.poly1d(polinomio)
    return poly




