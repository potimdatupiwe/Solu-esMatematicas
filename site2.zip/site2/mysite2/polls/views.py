from django.shortcuts import render
from django.http import HttpResponse
import polinomio as pn
import matplotlib.pyplot as plt
import os
import numpy as np
def polinomio2(request):
    if request.method == 'GET':
        return render(request, 'polls/index.html')
    else:
        polinomio3 = request.POST.get('polinomio2')
        po = pn.poly(polinomio3)
        r = np.roots(po)
        r2 = r.tolist()
        x = np.linspace(-10000, 10000)
        y = po(x)
        fig = plt.figure(clear=True)
        plt.plot(x,y)
        fig.savefig('pol.png')
        os.rename('/home/italo/Área de trabalho/site2/mysite2/pol.png','/home/italo/Área de trabalho/site2/mysite2/static/imagens/pol.png')
        context = {'r':r2,
                   'p':polinomio3}
        return render(request,'polls/resuts.html', context)
